//
//  MainBall.m
//  FlickBall
//
//  Created by Travis Delly on 9/27/15.
//  Copyright © 2015 Travis Delly. All rights reserved.
//

#import "MainBall.h"
#import "AppDelegate.h"

@implementation MainBall{
    
    AppDelegate *sharedDelegate;
    NSTimer *multiplierTimer;
    NSTimer *resetBodyTimer;
    
    float scale;
    NSTimer *shrinkBallTimer;
    
}

-(void)resetBody{
    self.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.size.height/2];
}

-(void)ballTexture{
    if(sharedDelegate.ballChoice == 1){
        self.texture = [SKTexture textureWithImageNamed:@"MainBall1"];
    } else if (sharedDelegate.ballChoice == 2){
        self.texture = [SKTexture textureWithImageNamed:@"MainBall2"];
    }else if (sharedDelegate.ballChoice == 3){
        self.texture = [SKTexture textureWithImageNamed:@"MainBall3"];
    }else if (sharedDelegate.ballChoice == 4){
        self.texture = [SKTexture textureWithImageNamed:@"MainBall4"];
    }else if (sharedDelegate.ballChoice == 5){
        self.texture = [SKTexture textureWithImageNamed:@"MainBall5"];
    }else if (sharedDelegate.ballChoice == 6){
        self.texture = [SKTexture textureWithImageNamed:@"MainBall6"];
    }
}

-(instancetype)initWithPosition:(CGPoint)position{
    
    self = [super init];
    if(self){
        sharedDelegate = [[UIApplication sharedApplication] delegate];
        
        [self ballTexture];
        
        _movement = 1;
        scale = 0;
        
        
        self.zPosition = 10;
        
        
        self.size = CGSizeMake(50, 50);
        self.position = CGPointMake(position.x, position.y);
        self.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.size.height/2];
        self.physicsBody.friction = 0;
        self.physicsBody.restitution = .6f;
        self.physicsBody.linearDamping = .2f;
        self.name = @"ball";
        self.physicsBody.categoryBitMask = sharedDelegate.mainBallCategory;
        self.physicsBody.contactTestBitMask = sharedDelegate.candyBallCategory;
        self.physicsBody.collisionBitMask = sharedDelegate.wallCategory | sharedDelegate.obstacleCategory;;
        
    }
    return self;
}

-(void)moveBall:(CGPoint)location :(CGPoint)previousLocation{
    
    if(_movement == 1 && sharedDelegate.gameOver == 0){
        double finalX = previousLocation.x - location.x;
        double finalY = previousLocation.y - location.y;
        
        [self.physicsBody applyImpulse:CGVectorMake(-finalX, -finalY)];
        
        [self.physicsBody applyTorque:.2];
    }
}


-(void)growBall{
    
    if(scale > 0){
        [shrinkBallTimer invalidate];
    } else {
        scale += 2.0f;
        SKAction *changeSize = [SKAction scaleBy:2.0f duration:1];
        [self runAction:changeSize];
    }
    
    shrinkBallTimer = [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(shrinkBall) userInfo:nil repeats:NO];
}
-(void)shrinkBall{
    SKAction *changeSize = [SKAction scaleBy:(1.0f/scale) duration:1];
    [self runAction:changeSize];
     scale = 0.0f;
}

-(void)multiplier{
    sharedDelegate.multiplier+=1;
    sharedDelegate.multiplier > 1 ?  [multiplierTimer invalidate] : nil;
    multiplierTimer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(cancelMultiplier) userInfo:nil repeats:NO];
}
-(void)cancelMultiplier{
    sharedDelegate.multiplier=1;
}

-(void)freezeBall{
    [self.physicsBody setVelocity:CGVectorMake(0, 0)];
    
    if(_movement == 0){
        [resetBodyTimer invalidate];
    }
    
    _movement = 0;
    self.texture = [SKTexture textureWithImageNamed:@"FrozenPlayball"];
    resetBodyTimer = [NSTimer scheduledTimerWithTimeInterval:4 target:self selector:@selector(unfreezeBall) userInfo:nil repeats:NO];
}
-(void)unfreezeBall{
    _movement = 1;
    [self ballTexture];
}
-(void)resetBall:(CGPoint)position{
    
    self.position = position;
    
    [shrinkBallTimer invalidate];
    [resetBodyTimer invalidate];
    
    self.physicsBody.velocity = CGVectorMake(0, 0);
    [self unfreezeBall];
    [self cancelMultiplier];
    self.size = CGSizeMake(50, 50);
}

@end
