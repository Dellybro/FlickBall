//
//  DoublePointBall.h
//  FlickBall
//
//  Created by Travis Delly on 10/2/15.
//  Copyright © 2015 Travis Delly. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface DoublePointBall : SKSpriteNode

-(id)initWithoutBodyAndPosition:(CGPoint)location;


-(void)ballHit;

@end
