//
//  BigBonusBall.h
//  FlickBall
//
//  Created by Travis Delly on 10/3/15.
//  Copyright © 2015 Travis Delly. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface BigBonusBall : SKSpriteNode

-(id)initWithoutBodyAndPosition:(CGPoint)location;
-(instancetype)initForTutorial:(CGPoint)position;
-(instancetype)init;

-(void)ballHit;

@end
