//
//  HTTPHelper.h
//  FlickBall
//
//  Created by Travis Delly on 10/9/15.
//  Copyright © 2015 Travis Delly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HTTPHelper : NSObject


-(NSMutableDictionary*)postMethod:(NSString*)post updateKey:(NSString*)updateKey action:(NSString*)action;
-(id)getMethod:(NSString*)method action:(NSString*)action;

@end
