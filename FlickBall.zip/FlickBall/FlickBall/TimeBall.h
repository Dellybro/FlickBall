//
//  TimeBall.h
//  FlickBall
//
//  Created by Travis Delly on 9/28/15.
//  Copyright © 2015 Travis Delly. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface TimeBall : SKSpriteNode

-(instancetype)init;
-(id)initWithoutBodyAndPosition:(CGPoint)location;

-(void)ballHit;
-(instancetype)initForSixtyMode;

@end
