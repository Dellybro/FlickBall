//
//  SixtySecondGameMode.m
//  FlickBall
//
//  Created by Travis Delly on 10/30/15.
//  Copyright © 2015 Travis Delly. All rights reserved.
//

#import "SixtySecondGameMode.h"
#import "AppDelegate.h"
#import "TimeBall.h"
#import "MovingBall.h"
#import "PoisonBall.h"
#import "FreezeBall.h"
#import "DoublePointBall.h"
#import "BigBonusBall.h"
#import "HomeScreen.h"
#import "Background.h"
#import "Obstacle.h"

@interface SixtySecondGameMode()

@property SKNode *obstacleHolders;
@property SKNode *candyBalls;
@property SKNode *randomBalls;
@property SKNode *labelsDuringGame;
@property SKNode *gameOverHolder;
@property SKNode *bonusBalls;

@property NSMutableArray *TimerArray;

//timerExtras
@property SKLabelNode *timer;
@property SKLabelNode *score;

@end

@implementation SixtySecondGameMode{
    AppDelegate *sharedDelegate;
}

-(void)makeRandomBall{
    
    int decision = arc4random() % 10;
    
    if(decision % 7){
    
        PoisonBall *poison = [[PoisonBall alloc] initForSixtyMode];
        [_randomBalls addChild:poison];
    } else if ( decision % 5){
        
        FreezeBall *freeze = [[FreezeBall alloc] initForSixtyMode];
        [_randomBalls addChild:freeze];
    }
    
}
-(void)makeBonusBalls{
    int decision = arc4random() % 10;
    
    if(decision % 5){
        
        
        BigBonusBall *BigBall = [[BigBonusBall alloc] init];
        [_bonusBalls addChild:BigBall];
    } else if ( decision % 4){
        DoublePointBall *doubleball = [[DoublePointBall alloc] init];
        [_bonusBalls addChild:doubleball];
    }
}
-(void)makeObstacles{
    Obstacle *newObstacle = [[Obstacle alloc] init:CGPointMake(85, 133)];
    
    [_obstacleHolders addChild:newObstacle];
}
//Making candies
-(void)makeCandy{
    
    
    int decision = arc4random() % 10;
    
    if(decision % 2 == 0){
        
        int counter;
        if(decision % 4 == 0){
            counter = 5;
        }else if(decision % 3 == 0){
            counter = 4;
        }else if(decision % 2 == 0){
            counter = 3;
        }
        
        for (int x = 0; x < counter; x++) {
            
            MovingBall *mainPointsBall = [[MovingBall alloc] initForSixtyMode];
        
            [_candyBalls addChild:mainPointsBall];
        }
    }
}

-(void)startTimers{
    
    _TimerArray = [[NSMutableArray alloc] init];
    //Gametimers
    NSTimer* timerEvent = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(decreaseTime) userInfo:nil repeats:YES];
    NSTimer* randomBallsTimer = [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(makeRandomBall) userInfo:nil repeats:YES];
    NSTimer* bonusBallTimer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(makeBonusBalls) userInfo:nil repeats:YES];
    NSTimer* makeCandyTimer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(makeCandy) userInfo:nil repeats:YES];
    NSTimer* obstacleTiemr = [NSTimer scheduledTimerWithTimeInterval:15 target:self selector:@selector(makeObstacles) userInfo:nil repeats:YES];
    
    [_TimerArray addObject:timerEvent];
    [_TimerArray addObject:randomBallsTimer];
    [_TimerArray addObject:bonusBallTimer];
    [_TimerArray addObject:makeCandyTimer];
    [_TimerArray addObject:obstacleTiemr];
}
-(void)invalidateTimers{
    
    for (NSTimer* timer in _TimerArray) {
        [timer invalidate];
    }
}

-(instancetype)initWithSize:(CGSize)size{
    self = [super initWithSize:size];
    if(self){
        sharedDelegate = [[UIApplication sharedApplication] delegate];
        
        //ADD BACKGROUND [Could make background Animated]
        Background *background = [[Background alloc] init];
        background.size = self.size;
        background.zPosition = 0;
        background.position = CGPointMake(self.size.width/2, self.size.height/2);
        [self addChild:background];
        
        //SETUP
        [self setup];
        
        
        self.physicsWorld.gravity = sharedDelegate.gameVelocity;
    }
    return self;
}

-(void)didBeginContact:(SKPhysicsContact *)contact{
    //BodyB will always be CandyBallCategory.
    if(contact.bodyB.categoryBitMask == sharedDelegate.candyBallCategory && sharedDelegate.gameOver == 0){
        
        
        //This is where I am able to figure out the class
        if([contact.bodyB.node class] == [TimeBall class]){

            //Ball hit
            TimeBall *ball = (TimeBall*)contact.bodyB.node;
            [ball ballHit];
            
            [_timer setText:[NSString stringWithFormat:@"%i", sharedDelegate.time]];
            
        }else if([contact.bodyB.node class] == [PoisonBall class]){
            //Ball hit
            PoisonBall *ball = (PoisonBall*)contact.bodyB.node;
            [ball ballHit];
            
            //Set GUI
            [_score setText:[NSString stringWithFormat:@"%i", sharedDelegate.score]];
            [_timer setText:[NSString stringWithFormat:@"%i", sharedDelegate.time]];
            
        } else if([contact.bodyB.node class] == [MovingBall class]){
            
            //Ball Hit
            MovingBall *ball = (MovingBall*)contact.bodyB.node;
            [ball ballHit];
            
            //Set GUI
            [_score setText:[NSString stringWithFormat:@"%i", sharedDelegate.score]];
            
        } else if([contact.bodyB.node class] == [FreezeBall class]){
            //Ball hit
            FreezeBall *ball = (FreezeBall*)contact.bodyB.node;
            [ball ballHit];
            
            //Make Ball do something
            [_ball freezeBall];
        } else if([contact.bodyB.node class] == [DoublePointBall class]){
            
            //Ball hit
            DoublePointBall *ball = (DoublePointBall*)contact.bodyB.node;
            [ball ballHit];
            
            //Make ball do something
            [_ball multiplier];
        } else if([contact.bodyB.node class] == [BigBonusBall class]){
            
            //Ball hit
            BigBonusBall *ball = (BigBonusBall*)contact.bodyB.node;
            [ball ballHit];
            
            //Make Ball do something
            [_ball growBall];
        }
    }
}


-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    for (UITouch* touch in touches) {
        [_ball moveBall:[touch locationInNode:self] :[touch previousLocationInNode:self]];
    }
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    for (UITouch* touch in touches) {
        
        CGPoint location = [touch locationInNode:self];
        if([[self nodeAtPoint:location].name isEqualToString:@"ball"]){
            //Stop the Ball if touched.
            [_ball.physicsBody setVelocity:CGVectorMake(0, 0)];
            
        } else if ([[self nodeAtPoint:location].name isEqualToString:@"playAgain"]){
            [self reSetupGame];
            //Method Right underneath this one
        } else if ([[self nodeAtPoint:location].name  isEqualToString:@"goHome"]){
            [self goHome];
        } else if ([[self nodeAtPoint:location].name  isEqualToString:@"goHighscores"]){
            [self goHighscore];
        }
    }
}

-(void)goHighscore{
        [sharedDelegate.gameCenter reportScore];
        [sharedDelegate.gameCenter showLeaderboardAndAchievements:YES view:self.view.window.rootViewController];
    //Or instantiate any controller from the storyboard with an indentifier
}

-(void)goHome{
    [self removeFromParent];
    HomeScreen *scene = [[HomeScreen alloc] initWithSize:self.size];
    
    [self.view presentScene:scene];
}

-(void)decreaseTime{
    if(sharedDelegate.time < 1){
        [self invalidateTimers];
        sharedDelegate.gameOver = 1;
        [self setupGameOver];
        
    } else {
        sharedDelegate.time--;
        [_timer setText:[NSString stringWithFormat:@"%i", sharedDelegate.time]];
    }
}



//setups


//ReSetup stuff
-(void)reSetupGame{
    
    [self startTimers];
    
    [sharedDelegate setupGameStuff];
    sharedDelegate.time = 60;
    
    [_candyBalls removeAllChildren];
    [_randomBalls removeAllChildren];
    [_obstacleHolders removeAllChildren];
    
    
    [_ball resetBall:CGPointMake(self.size.width/2, self.size.height/2)];
    _ball.zPosition = 15;
    
    
    [_score setText:[NSString stringWithFormat:@"%i", sharedDelegate.score]];
    
    //Timers
    [_timer setText:[NSString stringWithFormat:@"%i", sharedDelegate.time]];
    
    
    [_gameOverHolder removeAllChildren];
    [_gameOverHolder removeFromParent];
}

-(void)setupGameOver{
    
    SKSpriteNode *gameOverBackground = [sharedDelegate.customGUI defaultSKSprite:@"GameOverbackground" withPosition:CGPointMake(self.size.width/2, self.size.height/2-50) name:@"gameOverBackGround"];
    gameOverBackground.zPosition = 3;
    gameOverBackground.size = CGSizeMake(300, 500);
    
    //Title
    SKLabelNode *gameOverLabel = [sharedDelegate.customGUI defaultSKLabel:@"Game Over" withPosition:CGPointMake(self.size.width/2, self.size.height/2+200)];
    
    //Button
    SKSpriteNode *playAgain = [sharedDelegate.customGUI defaultSKSprite:@"reset" withPosition:CGPointMake(self.size.width/2+50, self.size.height/2-150) name:@"playAgain"];
    playAgain.size = CGSizeMake(56, 56);
    
    SKSpriteNode *goHome = [sharedDelegate.customGUI defaultSKSprite:@"Back" withPosition:CGPointMake(self.size.width/2-50, self.size.height/2-150) name:@"goHome"];
    
    SKSpriteNode *goHighscores = [sharedDelegate.customGUI defaultSKSprite:@"SubmitScore" withPosition:CGPointMake(self.size.width/2, self.size.height/2+100) name:@"goHighscores"];
    
    //BallTextures
    MovingBall *blueBall = [[MovingBall alloc] initWithoutBodyAndPosition:CGPointMake(self.size.width/2-100, self.size.height/2-75)];
    SKLabelNode *blueBallCount = [sharedDelegate.customGUI defaultSKLabel:[NSString stringWithFormat:@"x %i", sharedDelegate.MovingBallsHit] withPosition:CGPointMake(self.size.width/2-50, self.size.height/2-100)];
    
    TimeBall *timeBall = [[TimeBall alloc] initWithoutBodyAndPosition:CGPointMake(self.size.width/2+100, self.size.height/2-75)];
    SKLabelNode *TimeBallCount = [sharedDelegate.customGUI defaultSKLabel:[NSString stringWithFormat:@"x %i", sharedDelegate.TimeBallsHit] withPosition:CGPointMake(self.size.width/2+50, self.size.height/2-100)];
    
    PoisonBall *poisonBall = [[PoisonBall alloc] initWithoutBodyAndPosition:CGPointMake(self.size.width/2-100, self.size.height/2-25)];
    SKLabelNode *poisonBallCount = [sharedDelegate.customGUI defaultSKLabel:[NSString stringWithFormat:@"x %i", sharedDelegate.PoisonBallsHit] withPosition:CGPointMake(self.size.width/2-50, self.size.height/2-50)];
    
    FreezeBall *freezeBall = [[FreezeBall alloc] initWithoutBodyAndPosition:CGPointMake(self.size.width/2+100, self.size.height/2-25)];
    SKLabelNode *freezeBallCount = [sharedDelegate.customGUI defaultSKLabel:[NSString stringWithFormat:@"x %i", sharedDelegate.FreezeBallsHit] withPosition:CGPointMake(self.size.width/2+50, self.size.height/2-50)];
    
    
    BigBonusBall *bigBonusBall = [[BigBonusBall alloc] initWithoutBodyAndPosition:CGPointMake(self.size.width/2-100, self.size.height/2+25)];
    SKLabelNode *bigBonusBallCount = [sharedDelegate.customGUI defaultSKLabel:[NSString stringWithFormat:@"x %i", sharedDelegate.BigBonusBallsHit] withPosition:CGPointMake(self.size.width/2-50, self.size.height/2)];
    
    DoublePointBall *DoublePointsBall = [[DoublePointBall alloc] initWithoutBodyAndPosition:CGPointMake(self.size.width/2+100, self.size.height/2+25)];
    SKLabelNode *DoublePointsCount = [sharedDelegate.customGUI defaultSKLabel:[NSString stringWithFormat:@"x %i", sharedDelegate.DoublePointsHit] withPosition:CGPointMake(self.size.width/2+50, self.size.height/2)];
    
    

    
    [_gameOverHolder addChild:goHighscores];
    [_gameOverHolder addChild:bigBonusBall];
    [_gameOverHolder addChild:bigBonusBallCount];
    [_gameOverHolder addChild:DoublePointsBall];
    [_gameOverHolder addChild:DoublePointsCount];
    [_gameOverHolder addChild:TimeBallCount];
    [_gameOverHolder addChild:timeBall];
    [_gameOverHolder addChild:freezeBallCount];
    [_gameOverHolder addChild:freezeBall];
    [_gameOverHolder addChild:poisonBallCount];
    [_gameOverHolder addChild:poisonBall];
    [_gameOverHolder addChild:blueBallCount];
    [_gameOverHolder addChild:blueBall];
    [_gameOverHolder addChild:gameOverBackground];
    [_gameOverHolder addChild:goHome];
    [_gameOverHolder addChild:gameOverLabel];
    [_gameOverHolder addChild:playAgain];
    
    [self addChild:_gameOverHolder];
}

-(void)setup{
    
    //Shared Delegate stuff for Game
    [sharedDelegate setupGameStuff];
    sharedDelegate.time = 60;
    
    //CSetupHolders
    
    _obstacleHolders = [SKNode node];
    _obstacleHolders.zPosition = 5;
    _gameOverHolder = [SKNode node];
    _gameOverHolder.zPosition = 15;
    _candyBalls = [SKNode node];
    _candyBalls.zPosition = 3;
    _randomBalls = [SKNode node];
    _randomBalls.zPosition = 2;
    _labelsDuringGame = [SKNode node];
    _labelsDuringGame.zPosition = 5;
    _bonusBalls = [SKNode node];
    _bonusBalls.zPosition = 4;
    
    //Score and Timer Labels during game
    
    _score = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
    [_score setText:[NSString stringWithFormat:@"%i", sharedDelegate.score]];
    _score.position = CGPointMake(self.size.width/2+150, self.size.height/1.1);
    
    _timer = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
    [_timer setText:[NSString stringWithFormat:@"%i", sharedDelegate.time]];
    _timer.position = CGPointMake(self.size.width/2-150, self.size.height/1.1);
    
    [_labelsDuringGame addChild:_timer];
    [_labelsDuringGame addChild:_score];
    
    //Self frame and contactDelegate
    self.physicsWorld.contactDelegate = self;
    self.physicsBody = [SKPhysicsBody bodyWithEdgeLoopFromRect:self.frame];
    self.physicsBody.categoryBitMask = sharedDelegate.wallCategory;
    
    //Make Human Ball
    _ball = [[MainBall alloc] initWithPosition:CGPointMake(self.size.width/2, self.size.height/2)];
    
    
    [self addChild:_obstacleHolders];
    [self addChild:_bonusBalls];
    [self addChild:_labelsDuringGame];
    [self addChild:_randomBalls];
    [self addChild:_candyBalls];
    [self addChild:_ball];
    
    
    [self startTimers];
    
}

@end
