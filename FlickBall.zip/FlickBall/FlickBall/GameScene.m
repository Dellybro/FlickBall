//
//  GameScene.m
//  FlickBall
//
//  Created by Travis Delly on 9/27/15.
//  Copyright (c) 2015 Travis Delly. All rights reserved.
//

#import "GameScene.h"
#import "AppDelegate.h"
#import "TimeBall.h"
#import "MovingBall.h"
#import "PoisonBall.h"
#import "Utilities.h"
#import "FreezeBall.h"
#import "DoublePointBall.h"
#import "BigBonusBall.h"
#import "HomeScreen.h"
#import "Background.h"

@interface GameScene()


@property SKNode *candyBalls;
@property SKNode *randomBalls;
@property SKNode *labelsDuringGame;
@property SKNode *gameOverHolder;
@property SKNode *bonusBalls;


//timerExtras
@property NSTimer* randomBallsTimer;
@property NSTimer* bonusBallTimer;
@property NSTimer* timerEvent;
@property SKLabelNode *timer;
@property SKLabelNode *score;


@end



@implementation GameScene{
    AppDelegate *sharedDelegate;
}

-(instancetype)initWithSize:(CGSize)size{
    self = [super initWithSize:size];
    if(self){
        sharedDelegate = [[UIApplication sharedApplication] delegate];
        
        //ADD BACKGROUND [Could make background Animated]
        Background *background = [[Background alloc] init];
        background.size = self.size;
        background.zPosition = 0;
        background.position = CGPointMake(self.size.width/2, self.size.height/2);
        [self addChild:background];
        
        //SETUP
        [self setup];
        
        
        self.physicsWorld.gravity = sharedDelegate.gameVelocity;
        
        for (int x = 0; x < 3; x++) {
            [self makeCandy];
        }
        
        
    }
    return self;
}

-(void)decreaseTime{
    if(sharedDelegate.time < 1){
        [_timerEvent invalidate];
        sharedDelegate.gameOver = 1;
        [self setupGameOver];
        
    } else {
        sharedDelegate.time--;
        [_timer setText:[NSString stringWithFormat:@"%i", sharedDelegate.time]];
    }
}


//Handling the ball events
-(void)makeCandy{
        //MovingBallChoice
        MovingBall *movingBall = [[MovingBall alloc] init];
        [_candyBalls addChild:movingBall];
        [movingBall moveBall:[sharedDelegate.utils makeAPoint] :movingBall.position];
}

#pragma BallTouch
-(void)didBeginContact:(SKPhysicsContact *)contact{
    //BodyB will always be CandyBallCategory.
    if(contact.bodyB.categoryBitMask == sharedDelegate.candyBallCategory && sharedDelegate.gameOver == 0){
        
        
        //This is where I am able to figure out the class
        if([contact.bodyB.node class] == [TimeBall class]){
            
            //Ball hit
            TimeBall *ball = (TimeBall*)contact.bodyB.node;
            [ball ballHit];
            
            [_timer setText:[NSString stringWithFormat:@"%i", sharedDelegate.time]];
            
        }else if([contact.bodyB.node class] == [PoisonBall class]){
            //Ball hit
            PoisonBall *ball = (PoisonBall*)contact.bodyB.node;
            [ball ballHit];
            
            //Set GUI
            [_score setText:[NSString stringWithFormat:@"%i", sharedDelegate.score]];
            [_timer setText:[NSString stringWithFormat:@"%i", sharedDelegate.time]];
            
        } else if([contact.bodyB.node class] == [MovingBall class]){
            
            //Ball Hit
            MovingBall *ball = (MovingBall*)contact.bodyB.node;
            [ball ballHit];
            
            //Set GUI
            [_score setText:[NSString stringWithFormat:@"%i", sharedDelegate.score]];
            
        } else if([contact.bodyB.node class] == [FreezeBall class]){
            //Ball hit
            FreezeBall *ball = (FreezeBall*)contact.bodyB.node;
            [ball ballHit];
            
            //Make Ball do something
            [_ball freezeBall];
        } else if([contact.bodyB.node class] == [DoublePointBall class]){
            
            //Ball hit
            DoublePointBall *ball = (DoublePointBall*)contact.bodyB.node;
            [ball ballHit];
            
            //Make ball do something
            [_ball multiplier];
        } else if([contact.bodyB.node class] == [BigBonusBall class]){
            
            //Ball hit
            BigBonusBall *ball = (BigBonusBall*)contact.bodyB.node;
            [ball ballHit];
            
            //Make Ball do something
            [_ball growBall];
        }
        
        //Once game bonus' are awarded create X amount of candyBalls and remove Poison Balls
        if(_candyBalls.children.count == 0){
            
            sharedDelegate.levelCount++;
            sharedDelegate.count++;
            [_randomBalls removeAllChildren];
            
            sharedDelegate.utils.ArrayForMakeAPoint = [[NSMutableArray alloc] init];
            
            for (int x = 0; x < 4*(sharedDelegate.count/2); x++) {
                [self makeCandy];
            }
        }
        
    }
}

#pragma BallTouch
//FingerTouch events
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    for (UITouch* touch in touches) {
        [_ball moveBall:[touch locationInNode:self] :[touch previousLocationInNode:self]];
    }
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    for (UITouch* touch in touches) {
        
        CGPoint location = [touch locationInNode:self];
        if([[self nodeAtPoint:location].name isEqualToString:@"ball"]){
            //Stop the Ball if touched.
            [_ball.physicsBody setVelocity:CGVectorMake(0, 0)];
            
        } else if ([[self nodeAtPoint:location].name isEqualToString:@"playAgain"]){
            [self reSetupGame];
            //Method Right underneath this one
        } else if ([[self nodeAtPoint:location].name  isEqualToString:@"goHome"]){
            [self goHome];
        } else if ([[self nodeAtPoint:location].name  isEqualToString:@"goHighscores"]){
            
            [self goHighscore];
        }
    }
}

-(void)goHighscore{
    [sharedDelegate.gameCenter reportScore];
    [sharedDelegate.gameCenter showLeaderboardAndAchievements:YES view:self.view.window.rootViewController];
    //Or instantiate any controller from the storyboard with an indentifier
}

-(void)goHome{
    [self removeFromParent];
    HomeScreen *scene = [[HomeScreen alloc] initWithSize:self.size];
    
    [self.view presentScene:scene];
}


//DECIDE TO MAKE BALL
#pragma BallMake
-(void)decideToMakeTimeBallorPoisionBall{
    if(sharedDelegate.gameOver == 0){
        
        for (int x = 0; x < 3; x++) {
            
            int ballChoice = arc4random() % 100;
            
            if(ballChoice % 10 == 0 && sharedDelegate.time < 30){
                //Timerball Choice
                TimeBall *timeBall = [[TimeBall alloc] init];
                [_randomBalls addChild:timeBall];
            }else if(ballChoice % 9 == 0){
                //PoisonBall Choice
                PoisonBall *pBall = [[PoisonBall alloc] init];
                [_randomBalls addChild:pBall];
            }else if(ballChoice % 8 == 0) {
                //FreezeBalls
                FreezeBall *freezeBall = [[FreezeBall alloc] init];
                [_randomBalls addChild:freezeBall];
            }
        }
    }
    
}
-(void)decideToMakeBonusBall{
    if(sharedDelegate.gameOver == 0){
        int decisionNumber = arc4random() % 100;
        if(decisionNumber % 10 == 0){
            if(decisionNumber % 3 == 0){
                
                
                DoublePointBall *dpb;
                NSLog(@"DPB Made");
                if(decisionNumber % 3 == 0){
                    dpb = [[DoublePointBall alloc] init];
                } else {
                    dpb = [[DoublePointBall alloc] init];
                }
                
                [_bonusBalls addChild:dpb];
            }else{
                
                BigBonusBall *bonusBall;
                NSLog(@"Bonus Ball made");
                
                if(decisionNumber % 3 == 0){
                    bonusBall = [[BigBonusBall alloc] init];
                } else {
                    bonusBall = [[BigBonusBall alloc] init];
                }
                
                [_bonusBalls addChild:bonusBall];
            }
        }
        
    }
}


//Setup Stuff GameOver - Resetup - Setup
-(void)setupGameOver{
    
    
    SKSpriteNode *gameOverBackground = [sharedDelegate.customGUI defaultSKSprite:@"GameOverbackground" withPosition:CGPointMake(self.size.width/2, self.size.height/2-50) name:@"gameOverBackGround"];
    gameOverBackground.zPosition = 3;
    gameOverBackground.size = CGSizeMake(300, 500);
    
    //Title
    SKLabelNode *gameOverLabel = [sharedDelegate.customGUI defaultSKLabel:@"Game Over" withPosition:CGPointMake(self.size.width/2, self.size.height/2+200)];
    
    //Button
    SKSpriteNode *playAgain = [sharedDelegate.customGUI defaultSKSprite:@"reset" withPosition:CGPointMake(self.size.width/2+50, self.size.height/2-150) name:@"playAgain"];
    playAgain.size = CGSizeMake(56, 56);
    
    SKSpriteNode *goHome = [sharedDelegate.customGUI defaultSKSprite:@"Back" withPosition:CGPointMake(self.size.width/2-50, self.size.height/2-150) name:@"goHome"];
    
    SKSpriteNode *goHighscores = [sharedDelegate.customGUI defaultSKSprite:@"SubmitScore" withPosition:CGPointMake(self.size.width/2, self.size.height/2+100) name:@"goHighscores"];
    
    //BallTextures
    MovingBall *blueBall = [[MovingBall alloc] initWithoutBodyAndPosition:CGPointMake(self.size.width/2-100, self.size.height/2-75)];
    SKLabelNode *blueBallCount = [sharedDelegate.customGUI defaultSKLabel:[NSString stringWithFormat:@"x %i", sharedDelegate.MovingBallsHit] withPosition:CGPointMake(self.size.width/2-50, self.size.height/2-100)];
    
    TimeBall *timeBall = [[TimeBall alloc] initWithoutBodyAndPosition:CGPointMake(self.size.width/2+100, self.size.height/2-75)];
    SKLabelNode *TimeBallCount = [sharedDelegate.customGUI defaultSKLabel:[NSString stringWithFormat:@"x %i", sharedDelegate.TimeBallsHit] withPosition:CGPointMake(self.size.width/2+50, self.size.height/2-100)];
    
    PoisonBall *poisonBall = [[PoisonBall alloc] initWithoutBodyAndPosition:CGPointMake(self.size.width/2-100, self.size.height/2-25)];
    SKLabelNode *poisonBallCount = [sharedDelegate.customGUI defaultSKLabel:[NSString stringWithFormat:@"x %i", sharedDelegate.PoisonBallsHit] withPosition:CGPointMake(self.size.width/2-50, self.size.height/2-50)];
    
    FreezeBall *freezeBall = [[FreezeBall alloc] initWithoutBodyAndPosition:CGPointMake(self.size.width/2+100, self.size.height/2-25)];
    SKLabelNode *freezeBallCount = [sharedDelegate.customGUI defaultSKLabel:[NSString stringWithFormat:@"x %i", sharedDelegate.FreezeBallsHit] withPosition:CGPointMake(self.size.width/2+50, self.size.height/2-50)];
    
    
    BigBonusBall *bigBonusBall = [[BigBonusBall alloc] initWithoutBodyAndPosition:CGPointMake(self.size.width/2-100, self.size.height/2+25)];
    SKLabelNode *bigBonusBallCount = [sharedDelegate.customGUI defaultSKLabel:[NSString stringWithFormat:@"x %i", sharedDelegate.BigBonusBallsHit] withPosition:CGPointMake(self.size.width/2-50, self.size.height/2)];
    
    DoublePointBall *DoublePointsBall = [[DoublePointBall alloc] initWithoutBodyAndPosition:CGPointMake(self.size.width/2+100, self.size.height/2+25)];
    SKLabelNode *DoublePointsCount = [sharedDelegate.customGUI defaultSKLabel:[NSString stringWithFormat:@"x %i", sharedDelegate.DoublePointsHit] withPosition:CGPointMake(self.size.width/2+50, self.size.height/2)];
    
    
    
    
    [_gameOverHolder addChild:goHighscores];
    [_gameOverHolder addChild:bigBonusBall];
    [_gameOverHolder addChild:bigBonusBallCount];
    [_gameOverHolder addChild:DoublePointsBall];
    [_gameOverHolder addChild:DoublePointsCount];
    [_gameOverHolder addChild:TimeBallCount];
    [_gameOverHolder addChild:timeBall];
    [_gameOverHolder addChild:freezeBallCount];
    [_gameOverHolder addChild:freezeBall];
    [_gameOverHolder addChild:poisonBallCount];
    [_gameOverHolder addChild:poisonBall];
    [_gameOverHolder addChild:blueBallCount];
    [_gameOverHolder addChild:blueBall];
    [_gameOverHolder addChild:gameOverBackground];
    [_gameOverHolder addChild:goHome];
    [_gameOverHolder addChild:gameOverLabel];
    [_gameOverHolder addChild:playAgain];
    
    [self addChild:_gameOverHolder];
    
}

//ReSetup stuff
-(void)reSetupGame{
    
    [sharedDelegate setupGameStuff];
    
    [_candyBalls removeAllChildren];
    [_randomBalls removeAllChildren];
    
    for (int x = 0; x < 3; x++) {
        [self makeCandy];
    }
    
    [_ball resetBall:CGPointMake(self.size.width/2, self.size.height/2)];
    _ball.zPosition = 15;
    
    
    [_score setText:[NSString stringWithFormat:@"%i", sharedDelegate.score]];
    
    //Timers
    [_timer setText:[NSString stringWithFormat:@"%i", sharedDelegate.time]];
    _timerEvent = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(decreaseTime) userInfo:nil repeats:YES];
    
    [_gameOverHolder removeAllChildren];
    [_gameOverHolder removeFromParent];
}

-(void)setup{
    
    [sharedDelegate setupGameStuff];
    
    
    //GameoverStuff
    
    //CSetupHolders
    _gameOverHolder = [SKNode node];
    _gameOverHolder.zPosition = 15;
    _candyBalls = [SKNode node];
    _candyBalls.zPosition = 3;
    _randomBalls = [SKNode node];
    _randomBalls.zPosition = 2;
    _labelsDuringGame = [SKNode node];
    _labelsDuringGame.zPosition = 5;
    _bonusBalls = [SKNode node];
    _bonusBalls.zPosition = 4;
    
    //Score and Timer
    _score = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
    [_score setText:[NSString stringWithFormat:@"%i", sharedDelegate.score]];
    _score.position = CGPointMake(self.size.width/2+150, self.size.height/1.1);
    
    _timer = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
    [_timer setText:[NSString stringWithFormat:@"%i", sharedDelegate.time]];
    _timer.position = CGPointMake(self.size.width/2-150, self.size.height/1.1);
    
    [_labelsDuringGame addChild:_timer];
    [_labelsDuringGame addChild:_score];
    
    //Gametimers
    _timerEvent = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(decreaseTime) userInfo:nil repeats:YES];
    
    //Self frame and contactDelegate
    self.physicsWorld.contactDelegate = self;
    self.physicsBody = [SKPhysicsBody bodyWithEdgeLoopFromRect:self.frame];
    self.physicsBody.categoryBitMask = sharedDelegate.wallCategory;
    
    //Make Human Ball
    _ball = [[MainBall alloc] initWithPosition:CGPointMake(self.size.width/2, self.size.height/2)];
    
    
    //BonusBallTimer
    _bonusBallTimer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(decideToMakeBonusBall) userInfo:nil repeats:YES];
    _randomBallsTimer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(decideToMakeTimeBallorPoisionBall) userInfo:nil repeats:YES];
    
    
    [self addChild:_bonusBalls];
    [self addChild:_labelsDuringGame];
    [self addChild:_randomBalls];
    [self addChild:_candyBalls];
    [self addChild:_ball];
}

-(void)update:(CFTimeInterval)currentTime {
    /* Called before each frame is rendered */
}

@end
