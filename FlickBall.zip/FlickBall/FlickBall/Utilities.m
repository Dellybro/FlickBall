//
//  Utilities.m
//  FlickBall
//
//  Created by Travis Delly on 9/28/15.
//  Copyright © 2015 Travis Delly. All rights reserved.
//

#import "Utilities.h"

@implementation Utilities

-(instancetype)init{
    self = [super init];
    if(self) {
        _ArrayForMakeAPoint = [[NSMutableArray alloc] init];
    }
    return self;
}

-(CGPoint)makeAPointOffScreen{
    
    int decisionNumber = arc4random() % 2;
    if(decisionNumber % 2 == 0){
        return CGPointMake(-20, ((arc4random() % 450) + 200));
    } else {
        return CGPointMake(400, ((arc4random() % 450) + 200));
    }
    
}

-(void)pushBall:(SKSpriteNode*)ball{
    
    
    CGFloat changeX;
    CGFloat changeY;
    
    int decision = arc4random() * 10;
    if(decision % 3){
        changeX = 300.00f;
        changeY = 150;
        
    } else if( decision % 2){
        changeX = 200;
        changeY = 175;
        
    } else {
        changeX = 250;
        changeY = 125;
        
    }
    
    if(ball.position.x > 200){
        
        ball.physicsBody.velocity = CGVectorMake(-changeX, changeY);
        
    }else{
        ball.physicsBody.velocity = CGVectorMake(changeX, changeY);
        
    }
    
    SKAction *wait = [SKAction waitForDuration:5];
    SKAction *remove = [SKAction removeFromParent];
    
    SKAction *sequence = [SKAction sequence:@[wait, remove]];
    
    [ball runAction:sequence];
    
}

-(CGPoint)makeAPoint{
    CGPoint positionToReturn;
    int tryAgain = 1;
    while(tryAgain == 1){
        tryAgain = 0;
        
        int x = arc4random() % 295;
        x+=40;
        int y = arc4random() % 575;
        y+=50;
        
        positionToReturn = CGPointMake(x, y);
        NSValue *valueOfReturn = [NSValue valueWithCGPoint:positionToReturn];
        
        for (int x = 0; x < [_ArrayForMakeAPoint count]; x++) {
            if(valueOfReturn == [_ArrayForMakeAPoint objectAtIndex:x]){
                tryAgain = 1;
            }
        }
        if(tryAgain != 1){
            [_ArrayForMakeAPoint addObject:valueOfReturn];
        }
        
    }
    
    return positionToReturn;
}

@end
