//
//  Utilities.h
//  FlickBall
//
//  Created by Travis Delly on 9/28/15.
//  Copyright © 2015 Travis Delly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SpriteKit/SpriteKit.h>

@interface Utilities : NSObject

-(CGPoint)makeAPoint;
-(CGPoint)makeAPointOffScreen;
@property NSMutableArray *ArrayForMakeAPoint;

-(void)pushBall:(SKSpriteNode*)ball;
@end
