//
//  TutorialScene.m
//  FlickBall
//
//  Created by Travis Delly on 10/31/15.
//  Copyright © 2015 Travis Delly. All rights reserved.
//

#import "TutorialScene.h"
#import "Background.h"
#import "AppDelegate.h"
#import <math.h>
#import "MainBall.h"
#import "BigBonusBall.h"
#import "HomeScreen.h"

@interface TutorialScene()


@property SKLabelNode *pageTitle;

@property SKLabelNode *hints;

@property SKLabelNode *goodjob;

@property SKSpriteNode *hand;
@property SKSpriteNode *randomBall;
@property SKSpriteNode *arrows;

@property MainBall *ball;

@end

@implementation TutorialScene{
    AppDelegate *sharedDelegate;
    int swipeAllowed;
}

-(void)setup{
    self.physicsWorld.contactDelegate = self;
    self.physicsBody = [SKPhysicsBody bodyWithEdgeLoopFromRect:self.frame];
    self.physicsBody.categoryBitMask = sharedDelegate.wallCategory;
    self.physicsWorld.gravity = CGVectorMake(0, 0);
    

    
    _hand = [sharedDelegate.customGUI defaultSKSprite:@"handswipe" withPosition:CGPointMake(self.size.width/2+60, self.size.height/2-150) name:@"hand"];
    _hand.size = CGSizeMake(150, 150);
    [_hand runAction:[SKAction rotateByAngle:M_PI/5 duration:0]];
    
    
    _ball = [[MainBall alloc] initWithPosition:CGPointMake(50, self.size.height/2)];
    _ball.size = CGSizeMake(50, 50);
    
    _randomBall = [[BigBonusBall alloc] initForTutorial:CGPointMake(self.size.width-50, self.size.height/2)];
    _randomBall.size = CGSizeMake(50, 50);
    
    _hints = [sharedDelegate.customGUI defaultSKLabel:@"Click me!" withPosition:CGPointMake(self.size.width/2, self.size.height/2+200)];
    _hints.name = @"hint1";
    _hints.fontSize = 20;
    
    _goodjob = [sharedDelegate.customGUI defaultSKLabel:@"Welcome to Flick Ball!" withPosition:CGPointMake(_hints.position.x, _hints.position.y+50)];
    _goodjob.fontSize = 25;
    
    
    [self addChild:_goodjob];
    [self addChild:_hints];
    [self addChild:_hand];
    [self addChild:_ball];
    [self addChild:_randomBall];
}

-(void)didBeginContact:(SKPhysicsContact *)contact{
    _goodjob.text = @"Good job!";
    _hints.text = @"Click here to end Tutorial!";
    _hints.fontSize = 20;
    _hints.name = @"hint2";
    NSLog(@"contact");
    [_randomBall removeFromParent];
    [_ball growBall];
    
    SKLabelNode *KeepFlicking = [sharedDelegate.customGUI defaultSKLabel:@"Or keep flicking!!" withPosition:CGPointMake(_hints.position.x, _hints.position.y-50)];
    [self addChild:KeepFlicking];
}

-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    for (UITouch* touch in touches) {
        if(swipeAllowed == 1){
            [_ball moveBall:[touch locationInNode:self] :[touch previousLocationInNode:self]];
        }
    }
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    for (UITouch *touch in touches) {
        CGPoint location = [touch locationInNode:self];
        if([[self nodeAtPoint:location].name isEqualToString:@"hint1"]){
            
            //SKAction *move = [SKAction moveByX:-50 y:-25 duration:1];
            SKAction *rotate = [SKAction rotateByAngle:-M_PI/2 duration:.7];
            
            //SKAction *moveback = [SKAction moveByX:50 y:25 duration:1];
            SKAction *rotateback = [SKAction rotateByAngle:M_PI duration:.7];
            SKAction *rotatefinal = [SKAction rotateByAngle:-M_PI/2 duration:.7];
            
            SKAction *movement1 = [SKAction group:@[ rotate]];
            SKAction *movement2 = [SKAction group:@[ rotateback, rotatefinal]];
            
            SKAction *sequence = [SKAction sequence:@[movement1, movement2]];
            
            [_hand runAction:[SKAction repeatAction:sequence count:5]];
            
            swipeAllowed = 1;
            _hints.name = nil;
            _hints.text = @"Swipe the ball!";
        }if([[self nodeAtPoint:location].name isEqualToString:@"hint2"]){
            HomeScreen *home = [[HomeScreen alloc] initWithSize:self.size];
            
            [self removeFromParent];
            
            [self.view presentScene:home];
        }
        
    }
}

-(instancetype)initWithSize:(CGSize)size{
    self = [super initWithSize:size];
    if(self) {
        sharedDelegate = [[UIApplication sharedApplication] delegate];
        
        Background *background = [[Background alloc] init];
        background.texture = [SKTexture textureWithImageNamed:@"background6"];
        background.size = self.size;
        background.zPosition = 0;
        background.position = CGPointMake(self.size.width/2, self.size.height/2);
        [self addChild:background];
        
        [self setup];
        
    }
    return self;
}

@end
