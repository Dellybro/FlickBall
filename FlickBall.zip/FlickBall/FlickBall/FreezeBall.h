//
//  FreezeBall.h
//  FlickBall
//
//  Created by Travis Delly on 10/2/15.
//  Copyright © 2015 Travis Delly. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface FreezeBall : SKSpriteNode

-(instancetype)init;
-(id)initWithoutBodyAndPosition:(CGPoint)location;

-(void)ballHit;
-(instancetype)initForSixtyMode;
@end
